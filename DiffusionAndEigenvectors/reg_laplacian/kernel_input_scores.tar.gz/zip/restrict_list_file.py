"""
Removes entries from an input file from a list file.

This is useful for comparing the performance of list files with two
different input sets - say, testing prediction of high-conf genes
when medium-conf genes are or are not used as input.
(and vice versa)
In that case, we'd remove the "medium" genes from the list file.

python restrict_list_file.py input.list omit.tab
where input.list is formatted conf\tlabel\tgene
where omit.tab contains one gene per line. 
"""
import sys

# read omit list
omit=set()
with open(sys.argv[2]) as f:
	for line in f:
		if "#" in line[0:2]:
			continue	
		sp=line.strip().split("\t")
		omit.add(sp[0])
	
with open(sys.argv[1]) as f:
	for line in f:
		if "#" in line[0:2]:
			print line	
		sp=line.strip().split("\t")
		if sp[2] in omit:
			continue
		print line.strip()
